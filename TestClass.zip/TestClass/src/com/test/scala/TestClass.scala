package com.test.scala

class TestClass(message: String, secondaryMessage: String) {
    def SayHi() = println(message + secondaryMessage)
}

object TestClass{
def main(args:Array[String]) =  {
      var greeter = new TestClass(
    "Hello world!", 
    " This is a great world")
greeter.SayHi()

greeter = new TestClass(
    "Hello Earth!", 
    " This is a great Planet")
greeter.SayHi() }
}





  