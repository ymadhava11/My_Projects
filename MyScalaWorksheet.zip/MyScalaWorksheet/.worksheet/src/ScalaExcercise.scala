object ScalaExcercise {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(67); 
  println("Welcome to the Scala worksheet");$skip(70); val res$0 = 
  // Dealing with String operations
  "Hello, world".getClass.getName;System.out.println("""res0: String = """ + $show(res$0));$skip(25); 
  val s = "Hello, world";System.out.println("""s  : String = """ + $show(s ));$skip(11); val res$1 = 
  s.length;System.out.println("""res1: Int = """ + $show(res$1));$skip(30); 
  val s1 = "Hello" + " world";System.out.println("""s1  : String = """ + $show(s1 ));$skip(27); 
  "hello".foreach(println);$skip(32); 
  for (c <- "hello") println(c);$skip(30); 
  s.getBytes.foreach(println);$skip(46); 
  val result = "hello world".filter(_ != 'l');System.out.println("""result  : String = """ + $show(result ));$skip(37); val res$2 = 
  "scala".drop(2).take(2).capitalize;System.out.println("""res2: String = """ + $show(res$2));$skip(19); 
  val s2 = "Hello";System.out.println("""s2  : String = """ + $show(s2 ));$skip(19); 
  val s3 = "Hello";System.out.println("""s3  : String = """ + $show(s3 ));$skip(24); 
  val s4 = "H" + "ello";System.out.println("""s4  : String = """ + $show(s4 ));$skip(11); val res$3 = 
  s2 == s3;System.out.println("""res3: Boolean = """ + $show(res$3));$skip(11); val res$4 = 
  s1 == s3;System.out.println("""res4: Boolean = """ + $show(res$4));$skip(24); 
  val s5: String = null;System.out.println("""s5  : String = """ + $show(s5 ));$skip(11); val res$5 = 
  s3 == s5;System.out.println("""res5: Boolean = """ + $show(res$5));$skip(11); val res$6 = 
  s5 == s3;System.out.println("""res6: Boolean = """ + $show(res$6));$skip(35); val res$7 = 
  s2.toUpperCase == s3.toUpperCase;System.out.println("""res7: Boolean = """ + $show(res$7));$skip(24); 
  val s6: String = null;System.out.println("""s6  : String = """ + $show(s6 ));$skip(24); 
  val s7: String = null;System.out.println("""s7  : String = """ + $show(s7 ));$skip(11); val res$8 = 
  s6 == s7;System.out.println("""res8: Boolean = """ + $show(res$8));$skip(35); val res$9 = 
  s6.toUpperCase == s7.toUpperCase;System.out.println("""res9: Boolean = """ + $show(res$9))}
  
  
}
