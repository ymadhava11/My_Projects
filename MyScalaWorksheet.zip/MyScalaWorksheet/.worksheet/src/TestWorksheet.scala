object TestWorksheet {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(66); 
  println("Welcome to the Scala worksheet");$skip(11); 
  var x =5;System.out.println("""x  : Int = """ + $show(x ));$skip(26); 
  val str = "Scala Rocks";System.out.println("""str  : String = """ + $show(str ));$skip(29); 
  var odds = List(1,3,5,7,9);System.out.println("""odds  : List[Int] = """ + $show(odds ));$skip(9); val res$0 = 
  2 to 9;System.out.println("""res0: scala.collection.immutable.Range.Inclusive = """ + $show(res$0));$skip(15); 
  var y = true;System.out.println("""y  : Boolean = """ + $show(y ));$skip(16); 
  val pi = 3.14;System.out.println("""pi  : Double = """ + $show(pi ));$skip(30); 
  def add(a:Int, b:Int) = a+b;System.out.println("""add: (a: Int, b: Int)Int""");$skip(12); val res$1 = 
  add(4,10);System.out.println("""res1: Int = """ + $show(res$1));$skip(13); 
  val num =5;System.out.println("""num  : Int = """ + $show(num ));$skip(23); 
  val decimal = 5.2567;System.out.println("""decimal  : Double = """ + $show(decimal ));$skip(24); val res$2 = 
  List(1, true,"Peggy");System.out.println("""res2: List[Any] = """ + $show(res$2));$skip(16); 
  
  var m = 10;System.out.println("""m  : Int = """ + $show(m ));$skip(44); 
  
  while (m >=0){
  println(m)
  m-=1
  };$skip(31); 
 val triple = (x:Int) => x*x*x;System.out.println("""triple  : Int => Int = """ + $show(triple ));$skip(48); 
 def HigherOrder(m:Int,n:Int=>Int)=
 {
 n(m)
 };System.out.println("""HigherOrder: (m: Int, n: Int => Int)Int""");$skip(25); val res$3 = 
 
 HigherOrder(6,triple);System.out.println("""res3: Int = """ + $show(res$3));$skip(38); val res$4 = 
 
 
 "Hello, world".getClass.getName;System.out.println("""res4: String = """ + $show(res$4));$skip(24); 
 val s = "Hello, world";System.out.println("""s  : String = """ + $show(s ));$skip(10); val res$5 = 
 s.length;System.out.println("""res5: Int = """ + $show(res$5));$skip(31); 
 
 val s1 = "Hello" + " world";System.out.println("""s1  : String = """ + $show(s1 ));$skip(28); 
 
 "hello".foreach(println);$skip(30); 
for (c <- "hello") println(c);$skip(28); 
s.getBytes.foreach(println);$skip(45); 
 val result = "hello world".filter(_ != 'l');System.out.println("""result  : String = """ + $show(result ));$skip(38); val res$6 = 
 
 "scala".drop(2).take(2).capitalize;System.out.println("""res6: String = """ + $show(res$6));$skip(20); 
 
 val s3 = "Hello";System.out.println("""s3  : String = """ + $show(s3 ));$skip(20); 
 
 val s4 = "Hello";System.out.println("""s4  : String = """ + $show(s4 ));$skip(12); val res$7 = 
 
 s3 == s4;System.out.println("""res7: Boolean = """ + $show(res$7));$skip(26); 
 
 
val s5: String = null;System.out.println("""s5  : String = """ + $show(s5 ));$skip(10); val res$8 = 

s3 == s5;System.out.println("""res8: Boolean = """ + $show(res$8));$skip(44); 

val foo = """This is
a multiline
String""";System.out.println("""foo  : String = """ + $show(foo ));$skip(66); 



val speech = """Four score and
|seven years ago""".stripMargin;System.out.println("""speech  : String = """ + $show(speech ));$skip(70); 

val speech1 = """Four score and
#seven years ago""".stripMargin('#');System.out.println("""speech1  : String = """ + $show(speech1 ));$skip(140); 
                                        
val speech2 = """Four score and
|seven years ago
|our fathers""".stripMargin.replaceAll("\n", " ");System.out.println("""speech2  : String = """ + $show(speech2 ));$skip(130); 


val  singledoublequotes = """This is known as a
|"multiline" string
|or 'heredoc' syntax.""". stripMargin.replaceAll("\n", " ");System.out.println("""singledoublequotes  : String = """ + $show(singledoublequotes ));$skip(26); val res$9 = 

"hello world".split(" ");System.out.println("""res9: Array[String] = """ + $show(res$9));$skip(43); 

"hello world".split(" ").foreach(println);$skip(32); 

"Hello World".foreach(println);$skip(55); 

val commadelimited = "eggs, milk, butter, Coco Puffs";System.out.println("""commadelimited  : String = """ + $show(commadelimited ));$skip(27); val res$10 = 

commadelimited.split(",");System.out.println("""res10: Array[String] = """ + $show(res$10));$skip(39); val res$11 = 

commadelimited.split(",").map(_.trim);System.out.println("""res11: Array[String] = """ + $show(res$11));$skip(41); val res$12 = 

"hello world, this is Al".split("\\s+");System.out.println("""res12: Array[String] = """ + $show(res$12));$skip(19); 

val name = "Fred";System.out.println("""name  : String = """ + $show(name ));$skip(14); 

val age = 33;System.out.println("""age  : Int = """ + $show(age ));$skip(21); 

val weight = 200.00;System.out.println("""weight  : Double = """ + $show(weight ));$skip(65); 

println(s"$name is $age years old, and weighs $weight pounds.");$skip(39); 

println(s"Age next year: ${age + 1}");$skip(48); 

println(s"You are 33 years old: ${age == 33}")

case class Student (name:String, score:Int);$skip(81); 

val hannah = Student("Hannah", 95);System.out.println("""hannah  : TestWorksheet.Student = """ + $show(hannah ));$skip(59); 

println(s"${hannah.name} has a score of ${hannah.score}");$skip(68); 
println(f"$name is $age years old, and weighs $weight%.2f pounds.");$skip(69); 

println(f"$name is $age years old, and weighs $weight%.0f pounds.");$skip(51); 

val out = f"$name, you weigh $weight%.0f pounds.";System.out.println("""out  : String = """ + $show(out ));$skip(13); val res$13 = 

s"foo\nbar";System.out.println("""res13: String = """ + $show(res$13));$skip(65); val res$14 = 
                                                  
raw"foo\nbar";System.out.println("""res14: String = """ + $show(res$14));$skip(20); 

val name1 = "Fred";System.out.println("""name1  : String = """ + $show(name1 ));$skip(15); 

val age1 = 33;System.out.println("""age1  : Int = """ + $show(age1 ));$skip(54); 

val nameage = "%s is %d years old".format(name, age);System.out.println("""nameage  : String = """ + $show(nameage ));$skip(49); 

println("%s is %d years old".format(name, age));$skip(50); 
 

val upper = "hello, world".map(c => c.toUpper);System.out.println("""upper  : String = """ + $show(upper ));$skip(45); 


val upper1 = "hello, world".map(_.toUpper);System.out.println("""upper1  : String = """ + $show(upper1 ));$skip(66); 

val upperfiltered = "hello, world".filter(_!='r').map(_.toUpper);System.out.println("""upperfiltered  : String = """ + $show(upperfiltered ));$skip(31); 

for (c <- "hello") println(c);$skip(57); 

val toupper = for (c <- "hello, world") yield c.toUpper;System.out.println("""toupper  : String = """ + $show(toupper ));$skip(71); 

val results = for {
c <- "hello, world"
if c != 'l'
} yield c.toUpper;System.out.println("""results  : String = """ + $show(results ));$skip(30); 


val numPattern = "[0-9]+".r;System.out.println("""numPattern  : scala.util.matching.Regex = """ + $show(numPattern ));$skip(43); 

val address = "123 Main Street Suite 101";System.out.println("""address  : String = """ + $show(address ));$skip(50); 

val firstMatch = numPattern.findFirstIn(address);System.out.println("""firstMatch  : Option[String] = """ + $show(firstMatch ));$skip(45); 

val matches = numPattern.findAllIn(address);System.out.println("""matches  : scala.util.matching.Regex.MatchIterator = """ + $show(matches ));$skip(26); 

matches.foreach(println);$skip(54); 

val matches1 = numPattern.findAllIn(address).toArray;System.out.println("""matches1  : Array[String] = """ + $show(matches1 ))}

}
