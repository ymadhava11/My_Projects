object ScalaLessons_Part1 {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(71); 
  println("Welcome to the Scala worksheet");$skip(43); 
  
  // Scalar Datatypes
  var a_int:Int=3;System.out.println("""a_int  : Int = """ + $show(a_int ));$skip(22); 
  var a_char:Char='a';System.out.println("""a_char  : Char = """ + $show(a_char ));$skip(27); 
  var a_long:Long=83456789;System.out.println("""a_long  : Long = """ + $show(a_long ));$skip(10); 
  var b=3;System.out.println("""b  : Int = """ + $show(b ));$skip(17); 
  var b_char='d';System.out.println("""b_char  : Char = """ + $show(b_char ));$skip(28); 
  var b_long=8345679099090l;System.out.println("""b_long  : Long = """ + $show(b_long ));$skip(22); 
  var c_float=1.2345f;System.out.println("""c_float  : Float = """ + $show(c_float ));$skip(15); 
  val c=109809;System.out.println("""c  : Int = """ + $show(c ));$skip(56); 
  
   //Mutable vs Immutable
  val Hello:String="Hello";System.out.println("""Hello  : String = """ + $show(Hello ));$skip(32); 
  var HelloThere:String="There";System.out.println("""HelloThere  : String = """ + $show(HelloThere ));$skip(32); 
  HelloThere=Hello + HelloThere;$skip(22); 
  println(HelloThere);$skip(63); 
  
  // Initializing different datatypes
  val numberone:Int=1;System.out.println("""numberone  : Int = """ + $show(numberone ));$skip(25); 
  val truth:Boolean=true;System.out.println("""truth  : Boolean = """ + $show(truth ));$skip(23); 
  val letterA:Char='A';System.out.println("""letterA  : Char = """ + $show(letterA ));$skip(23); 
  val pi:Double=3.1417;System.out.println("""pi  : Double = """ + $show(pi ));$skip(36); 
  val piSinglePrecision:Float=3.14f;System.out.println("""piSinglePrecision  : Float = """ + $show(piSinglePrecision ));$skip(32); 
  val bigNumber:Long=1234567890;System.out.println("""bigNumber  : Long = """ + $show(bigNumber ));$skip(27); 
  val smallNumber:Byte=127;System.out.println("""smallNumber  : Byte = """ + $show(smallNumber ));$skip(182); 
  
  // Concatenating values of different types : implicit type conversion to string
  println("Here is a mess:"+ numberone+truth+letterA+pi+piSinglePrecision+bigNumber+smallNumber);$skip(72); 
  // Number formatting
  println(f"pi is about $piSinglePrecision%.1f");$skip(53); 
 println(f"Zero padding on the left:$numberone%05d");$skip(110); 
 //string substitution
 println(s"I can use the s prefix to use variables like $numberone $truth $bigNumber");$skip(99); 
println(s"The s prefix isn't limited to variables; I can include expression as well. like ${1+2}");$skip(91); 
//Regular Expressions
val theUltimateAnswer="To life, the universe, and everything is 42.";System.out.println("""theUltimateAnswer  : String = """ + $show(theUltimateAnswer ));$skip(32); 
val pattern=""".* ([\d]).*""".r;System.out.println("""pattern  : scala.util.matching.Regex = """ + $show(pattern ));$skip(44); 
val pattern(answerstring)=theUltimateAnswer;System.out.println("""answerstring  : String = """ + $show(answerstring ));$skip(30); 
val answer=answerstring.toInt;System.out.println("""answer  : Int = """ + $show(answer ));$skip(16); 
println(answer);$skip(52); 

// Dealing with Booleans
val isGreater:Boolean=1>2;System.out.println("""isGreater  : Boolean = """ + $show(isGreater ));$skip(25); 
val isLesser:Boolean=1<2;System.out.println("""isLesser  : Boolean = """ + $show(isLesser ));$skip(36); 
val impossible=isGreater & isLesser;System.out.println("""impossible  : Boolean = """ + $show(impossible ));$skip(37); 
val anotherway=isGreater && isLesser;System.out.println("""anotherway  : Boolean = """ + $show(anotherway ));$skip(21); 

val picard="Picard";System.out.println("""picard  : String = """ + $show(picard ));$skip(25); 
val bestcaptain="Picard";System.out.println("""bestcaptain  : String = """ + $show(bestcaptain ));$skip(39); 
val isBest:Boolean=picard==bestcaptain;System.out.println("""isBest  : Boolean = """ + $show(isBest ));$skip(97); 

// Flow control
// if else
if (1>3) println("Impossible") else println("The world makes sense");$skip(85); 
if (1>3)
{
println("Impossible")
}
else
{
println("The world makes perfect sense")
};$skip(60); 

// matching - switch case in other languages
val number =3;System.out.println("""number  : Int = """ + $show(number ));$skip(130); 
number match {
case 1 => println("One")
case 2 => println("Two")
case 3 => println("Three")
case _ => println("Something Else")
};$skip(70); 

// For loops
for (x<- 1 to 4)
{
val squared = x*x
println(squared)
};$skip(22); 
// while loop
var x=0;System.out.println("""x  : Int = """ + $show(x ));$skip(32); 
while(x>=10){
println(x)
x+=1
};$skip(18); 
//do while
 x = 0;$skip(42); 
  do { println(x); x+=1 } while (x <= 10);$skip(168); val res$0 = 
                                                  
   // Expressions
   // "Returns" the final value in a block automatically
 
 // Expression
    {val x = 10; x + 20};System.out.println("""res0: Int = """ + $show(res$0));$skip(41); 
    
    	 println({val x = 10; x + 20});$skip(670); 
  
  // Scala Collections - Sequences, Sets, Maps -- arrays of numbers or sets of labels --> collections of data
  // Seqs -> Streams, lists, queues, Strings, stacks, vectors
  // Sets -> Hashset, sortedset, Treeset, bitset, Listset  -- can be sorted, tree based or based on hash
  // Maps -> Hashmaps, SortedMaps, TreeMaps, ListMaps
  // Collections are either mutable or immutable --> Mutable can change, immutable can't change
  
  // Arrays - indexed collections of values, Mutable collection type, Index values start from 0, variables including arrays are objects and have associated methods
  //Eg: Arrays of temperatures
  
  val temps = Array(50,51,52,55,56,89);System.out.println("""temps  : Array[Int] = """ + $show(temps ));$skip(11); val res$1 = 
  temps(0);System.out.println("""res1: Int = """ + $show(res$1));$skip(15); val res$2 = 
  temps.length;System.out.println("""res2: Int = """ + $show(res$2));$skip(14); 
  temps(0)=52;$skip(43); 
  val temps2:Array[Int]=new Array[Int](10);System.out.println("""temps2  : Array[Int] = """ + $show(temps2 ));$skip(39); 
  val temps3 = Array.ofDim[Int](10,10)
  
  // To use the Array oriented functions, use the package Array._
  import Array._;System.out.println("""temps3  : Array[Array[Int]] = """ + $show(temps3 ));$skip(109); val res$3 = 
  concat(temps,temps2);System.out.println("""res3: Array[Int] = """ + $show(res$3));$skip(166); 
  
  
  // Vectors - are like arrays, supported indexed data access in a collection, immutable collection of data
  
  val vec1:Vector[Int]=Vector(1,2,3,4,5,6,7,8,9);System.out.println("""vec1  : Vector[Int] = """ + $show(vec1 ));$skip(10); val res$4 = 
  vec1(2);System.out.println("""res4: Int = """ + $show(res$4));$skip(234); 
  
  // Range - data structure for representing integer values - in a range from certain start & end values, includes the start & end values, by default, a range has a step value of 1
  // Immutable collection
  val myRange = 1 to 10;System.out.println("""myRange  : scala.collection.immutable.Range.Inclusive = """ + $show(myRange ));$skip(42); 
  val myRange2:Range = new Range(1,101,2);System.out.println("""myRange2  : Range = """ + $show(myRange2 ));$skip(237); 
  
  // Maps - Used for groups of key value pairs - Mutable collection
  // Eg; Country Capitals & capital cities
  
  val capitals = Map("Argentina" -> "Buenos Aires", "Canada" -> "Ottawa", "Egypt" -> "Ottawa", "Liberia" -> "Monrovia");System.out.println("""capitals  : scala.collection.immutable.Map[String,String] = """ + $show(capitals ));$skip(16); val res$5 = 
  capitals.keys;System.out.println("""res5: Iterable[String] = """ + $show(res$5));$skip(18); val res$6 = 
  capitals.values;System.out.println("""res6: Iterable[String] = """ + $show(res$6));$skip(27); val res$7 = 
  capitals get "Argentina";System.out.println("""res7: Option[String] = """ + $show(res$7));$skip(24); val res$8 = 
  capitals("Argentina");System.out.println("""res8: String = """ + $show(res$8));$skip(24); val res$9 = 
  capitals get "Mexico";System.out.println("""res9: Option[String] = """ + $show(res$9));$skip(28); val res$10 = 
  capitals contains "Egypt";System.out.println("""res10: Boolean = """ + $show(res$10));$skip(51); val res$11 = 
  capitals getOrElse ("china","No Capitals Found");System.out.println("""res11: String = """ + $show(res$11));$skip(37); val res$12 = 
  capitals + ("Ireland" -> "Dublin");System.out.println("""res12: scala.collection.immutable.Map[String,String] = """ + $show(res$12));$skip(23); val res$13 = 
  capitals - "Liberia";System.out.println("""res13: scala.collection.immutable.Map[String,String] = """ + $show(res$13));$skip(316); 
  
  
  // Data structures
  
  // Tuples (Also really common with Spark!!) - Index starts from 1
  // Immutable lists
  // Often thought of as database fields, or columns - elements of different types
  // Useful for passing around entire rows of data.
  
  val captainStuff=("Picard","Enterprise-D","NCC-1701-D");System.out.println("""captainStuff  : (String, String, String) = """ + $show(captainStuff ));$skip(27); 
  
  println(captainStuff);$skip(103); 
  
    // You refer to individual fields with their ONE-BASED index:
    
    println(captainStuff._1);$skip(29); 
    println(captainStuff._2);$skip(29); 
    println(captainStuff._3);$skip(100); 
    
    // You can create a key/value pair with ->
    val picardShip = "Picard" -> "Enterprise-D";System.out.println("""picardShip  : (String, String) = """ + $show(picardShip ));$skip(27); 
    println(picardShip._1);$skip(27); 
    println(picardShip._2);$skip(97); 
    
    // You can mix different types in a tuple
     val aBunchOfStuff = ("Kirk", 1964, true);System.out.println("""aBunchOfStuff  : (String, Int, Boolean) = """ + $show(aBunchOfStuff ));$skip(266); 
    
   // Lists - Index starts from 0 - elements of same type
 // Like a tuple, but it's an actual Collection object that has more functionality.
 // It's a singly-linked list under the hood.
 
 val shipList=List("Enterprise","Defiant","Voyager","Deep Space Nine");System.out.println("""shipList  : List[String] = """ + $show(shipList ));$skip(22); 
 println(shipList(0));$skip(95); 
 
 // head and tail give you the first item, and the remaining ones.
 
 println(shipList.head);$skip(24); 
 println(shipList.tail);$skip(44); 
 
 for (ship <- shipList)
 {
 println(ship)
 };$skip(187); 
 
 // Let's apply a function literal to a list! map() can be used to apply any function to every item in a collection.
 
 val shipReverse= shipList.map((ship:String)=> {ship.reverse});System.out.println("""shipReverse  : List[String] = """ + $show(shipReverse ));$skip(72); 
 
 // reduce function to compute the sum
 val testList =List(1,2,3,4,5);System.out.println("""testList  : List[Int] = """ + $show(testList ));$skip(51); 
 val sum = testList.reduce((x:Int,y:Int) => {x+y});System.out.println("""sum  : Int = """ + $show(sum ));$skip(91); 
 
 // filter the list to remove value 2
 val filterList = testList.filter((x:Int)=>{x!=2});System.out.println("""filterList  : List[Int] = """ + $show(filterList ));$skip(43); 
 
 val filterList2 = testList.filter(_!=2);System.out.println("""filterList2  : List[Int] = """ + $show(filterList2 ));$skip(233); 
 
 
 // Note that Spark has its own map, reduce, and filter functions that can distribute these operations. But they work the same way!
// Also, you understand MapReduce now :)

// Concatenating lists
val moreNumbers=List(8,9,0,1,7);System.out.println("""moreNumbers  : List[Int] = """ + $show(moreNumbers ));$skip(38); 
val newList = testList ++ moreNumbers;System.out.println("""newList  : List[Int] = """ + $show(newList ));$skip(56); 

// more List Operations
val reversed = newList.reverse;System.out.println("""reversed  : List[Int] = """ + $show(reversed ));$skip(29); 
val sorted = reversed.sorted;System.out.println("""sorted  : List[Int] = """ + $show(sorted ));$skip(31); 
val distinct = sorted.distinct;System.out.println("""distinct  : List[Int] = """ + $show(distinct ));$skip(23); 
val max = distinct.max;System.out.println("""max  : Int = """ + $show(max ));$skip(23); 
val min = distinct.min;System.out.println("""min  : Int = """ + $show(min ));$skip(26); 
val sumall = distinct.sum;System.out.println("""sumall  : Int = """ + $show(sumall ));$skip(34); 
val is5there=distinct.contains(5);System.out.println("""is5there  : Boolean = """ + $show(is5there ));$skip(224); 


// Maps
// Useful for key/value lookups on distinct keys
// Like dictionaries in other languages

val shipMap = Map("Kirk" -> "Enterprise", "Picard" -> "Enterprise-D", "Sisko" -> "Deep Space Nine", "Janeway" -> "Voyager");System.out.println("""shipMap  : scala.collection.immutable.Map[String,String] = """ + $show(shipMap ));$skip(26); 
println(shipMap("Sisko"));$skip(66); 

// Dealing with missing keys
println(shipMap.contains("Archer"));$skip(67); 

val archersShip = util.Try(shipMap("Archer")) getOrElse "Unknown";System.out.println("""archersShip  : String = """ + $show(archersShip ));$skip(65); 
val PicardShip = util.Try(shipMap("Picard")) getOrElse "Unknown";System.out.println("""PicardShip  : String = """ + $show(PicardShip ));$skip(37); 

// Other Operations
val x1 = 2 to 9;System.out.println("""x1  : scala.collection.immutable.Range.Inclusive = """ + $show(x1 ));$skip(22); val res$14 = 
1.0f.getClass.getName;System.out.println("""res14: String = """ + $show(res$14));$skip(23); 
val s = "Hello, world";System.out.println("""s  : String = """ + $show(s ));$skip(9); val res$15 = 
s.length;System.out.println("""res15: Int = """ + $show(res$15));$skip(19); 
s.foreach(println);$skip(29); val res$16 = 
s.drop(2).take(2).capitalize;System.out.println("""res16: String = """ + $show(res$16));$skip(43); 
val foo = """This is
a multiline
String""";System.out.println("""foo  : String = """ + $show(foo ));$skip(64); 

val speech = """Four score and
|seven years ago""".stripMargin;System.out.println("""speech  : String = """ + $show(speech ));$skip(17); 

println(speech);$skip(69); 
val speech1 = """Four score and
#seven years ago""".stripMargin('#');System.out.println("""speech1  : String = """ + $show(speech1 ));$skip(99); 
val speech2 = """Four score and
|seven years ago
|our fathers""".stripMargin.replaceAll("\n", " ");System.out.println("""speech2  : String = """ + $show(speech2 ));$skip(26); val res$17 = 

"hello world".split(" ");System.out.println("""res17: Array[String] = """ + $show(res$17));$skip(55); 

val commadelimited = "eggs, milk, butter, Coco Puffs";System.out.println("""commadelimited  : String = """ + $show(commadelimited ));$skip(62); 
 
val arraycommadelim = commadelimited.split(",").map(_.trim);System.out.println("""arraycommadelim  : Array[String] = """ + $show(arraycommadelim ));$skip(41); val res$18 = 

"hello world, this is Al".split("\\s+");System.out.println("""res18: Array[String] = """ + $show(res$18));$skip(29); 

val numPattern = "[0-9]+".r;System.out.println("""numPattern  : scala.util.matching.Regex = """ + $show(numPattern ));$skip(42); 
val address = "123 Main Street Suite 101";System.out.println("""address  : String = """ + $show(address ));$skip(49); 
val firstMatch = numPattern.findFirstIn(address);System.out.println("""firstMatch  : Option[String] = """ + $show(firstMatch ));$skip(47); 
val allMatches = numPattern.findAllIn(address);System.out.println("""allMatches  : scala.util.matching.Regex.MatchIterator = """ + $show(allMatches ));$skip(28); 
allMatches.foreach(println);$skip(55); 
val matchArray = numPattern.findAllIn(address).toArray;System.out.println("""matchArray  : Array[String] = """ + $show(matchArray ));$skip(87); val res$19 = 
  
  // Scala Expressions - Computable statements
  // Arithmetic expressions
  
  2+4;System.out.println("""res19: Int(6) = """ + $show(res$19));$skip(9); val res$20 = 
  100-80;System.out.println("""res20: Int(20) = """ + $show(res$20));$skip(6); val res$21 = 
  4*6;System.out.println("""res21: Int(24) = """ + $show(res$21));$skip(7); val res$22 = 
  33/4;System.out.println("""res22: Int(8) = """ + $show(res$22));$skip(7); val res$23 = 
  33%6;System.out.println("""res23: Int(3) = """ + $show(res$23));$skip(10); val res$24 = 
  
 3 > 5;System.out.println("""res24: Boolean(false) = """ + $show(res$24));$skip(8); val res$25 = 
 5 <=10;System.out.println("""res25: Boolean(true) = """ + $show(res$25));$skip(68); val res$26 = 
 
 // Combine expressions using logical operators
 (3>4) && (5<=10);System.out.println("""res26: Boolean = """ + $show(res$26));$skip(18); val res$27 = 
 (3>4) || (5<=10);System.out.println("""res27: Boolean = """ + $show(res$27));$skip(8); val res$28 = 
 !(3>4);System.out.println("""res28: Boolean = """ + $show(res$28));$skip(13); 

var a1 = 10;System.out.println("""a1  : Int = """ + $show(a1 ));$skip(12); 
var b1 = 20;System.out.println("""b1  : Int = """ + $show(b1 ));$skip(12); 
var c1 = 30;System.out.println("""c1  : Int = """ + $show(c1 ));$skip(7); 
c1+=a1;$skip(8); 

c1*=a1;$skip(31); 

println({
var a2= 2*3
a2+4
});$skip(170); 


// Functions - useful for grouping related expression into logical units of work and specifying computations
def myFunction(a:Int,b:Int):Int = {
val c = a*b
return c
};System.out.println("""myFunction: (a: Int, b: Int)Int""");$skip(17); val res$29 = 

myFunction(2,3);System.out.println("""res29: Int = """ + $show(res$29));$skip(55); 

def myProcedure(inStr:String):Unit={
println(inStr)
};System.out.println("""myProcedure: (inStr: String)Unit""");$skip(37); 
myProcedure("This is a log Message");$skip(59); 

// Square the number
 def squareInt(x:Int):Int ={
 x*x
 };System.out.println("""squareInt: (x: Int)Int""");$skip(57); 
 
 // Cube the number
 def cubeIt(x:Int):Int={
 x*x*x
 };System.out.println("""cubeIt: (x: Int)Int""");$skip(25); 
 
 println(squareInt(3));$skip(20); 
 println(cubeIt(3));$skip(105); 
 
 // using function as an argument to another function
 
 def transformInt(x:Int,f:Int=>Int)={
 f(x)
 };System.out.println("""transformInt: (x: Int, f: Int => Int)Int""");$skip(40); 
 
 val result = transformInt(10,cubeIt);System.out.println("""result  : Int = """ + $show(result ));$skip(17); 
 println(result);$skip(205); val res$30 = 
 
 
 // "Lambda functions", "anonymous functions", "function literals"
  // You can declare functions inline without even giving them a name
  // This happens a lot in Spark.
  
  transformInt(3,x=>x*x*x);System.out.println("""res30: Int = """ + $show(res$30));$skip(26); val res$31 = 
  transformInt(10,x=>x/2);System.out.println("""res31: Int = """ + $show(res$31));$skip(42); val res$32 = 
  
  transformInt(5,x=>{val y=x*2;y*y*4});System.out.println("""res32: Int = """ + $show(res$32));$skip(191); 


// Scala classes & Objects
// Classes are definitions of structures and operations on those structures
// variables are all objects

val y = Array("England","Liberia","Australia","London");System.out.println("""y  : Array[String] = """ + $show(y ));$skip(9); val res$33 = 
y.sorted;System.out.println("""res33: Array[String] = """ + $show(res$33));$skip(627); 

//class location(var latitude:Int, var lat_direction:Char, var longitude:Int, var long_direction:Char, var altutude:Int)

//val loc1 = new location(45,'N',120,'N',300)

//loc1.altitude

// Parallel collections
// Take advantage of multi core processors & hyper threaded processors
// common practice is to use for loop to process each element of a collection, one at a time, works well for small collections.
// thousands of elements in a collection and processing time adds up.

// Sequential collections : Arrays, Vectors, HashMap, Hashset
// Parallel collections : ParArrays, ParVector, ParHashMap

val range100 = 1 to 100;System.out.println("""range100  : scala.collection.immutable.Range.Inclusive = """ + $show(range100 ));$skip(24); 
val prng = range100.par
                                                  

import scala.collection.parallel.immutable.ParVector;System.out.println("""prng  : scala.collection.parallel.immutable.ParRange = """ + $show(prng ));$skip(148); 
val parvector200 = ParVector.range(0,200);System.out.println("""parvector200  : scala.collection.parallel.immutable.ParVector[Int] = """ + $show(parvector200 ));$skip(78); 

// can convert sequantial to parallel collections
val v = (1 to 100).toArray;System.out.println("""v  : Array[Int] = """ + $show(v ));$skip(15); 
val pv = v.par;System.out.println("""pv  : scala.collection.parallel.mutable.ParArray[Int] = """ + $show(pv ));$skip(11); val res$34 = 
v.map(_*4);System.out.println("""res34: Array[Int] = """ + $show(res$34));$skip(12); val res$35 = 
pv.map(_*4);System.out.println("""res35: scala.collection.parallel.mutable.ParArray[Int] = """ + $show(res$35));$skip(39); 

def square(x:Int):Int = {
return x*x};System.out.println("""square: (x: Int)Int""");$skip(18); val res$36 = 

v.map(square(_));System.out.println("""res36: Array[Int] = """ + $show(res$36));$skip(18); val res$37 = 
pv.map(square(_));System.out.println("""res37: scala.collection.parallel.mutable.ParArray[Int] = """ + $show(res$37));$skip(112); 

// Perform computations in parallel by taking advantage of multi core processors
val v1 = (1 to 10000).toArray;System.out.println("""v1  : Array[Int] = """ + $show(v1 ));$skip(10); val res$38 = 
v1.length;System.out.println("""res38: Int = """ + $show(res$38));$skip(17); 
val pv1 = v1.par;System.out.println("""pv1  : scala.collection.parallel.mutable.ParArray[Int] = """ + $show(pv1 ));$skip(11); val res$39 = 
pv1.length;System.out.println("""res39: Int = """ + $show(res$39));$skip(116); 

// Filtering the collection - filter accepts a function that returns a boolean value

val pvf = pv1.filter(_>5000);System.out.println("""pvf  : scala.collection.parallel.mutable.ParArray[Int] = """ + $show(pvf ));$skip(39); 




val pvfnot = pv1.filterNot(_>5000);System.out.println("""pvfnot  : scala.collection.parallel.mutable.ParArray[Int] = """ + $show(pvfnot ));$skip(66); 


def div3 (x:Int):Boolean = {
val y:Int = (x%3); return (y==0)
};System.out.println("""div3: (x: Int)Boolean""");$skip(9); val res$40 = 

div3(9);System.out.println("""res40: Boolean = """ + $show(res$40));$skip(21); val res$41 = 

pv1.filter(div3(_));System.out.println("""res41: scala.collection.parallel.mutable.ParArray[Int] = """ + $show(res$41))}

// when do you really need to use parallel collections ?
// 1. Collections with atleast tens of thousands of elements 2. for some types of collections, converting between sequential and parallel requires copying the content of
// the collections to be copied 3.Best to avoid any procedures that lead of side effects (side effects lead to non-deterministic results) 4. Avoid nonassociative operations (Nonassociate operations
// don't depend on the order &  state information.




}
