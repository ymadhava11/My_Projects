object ScalaLearnings {;import org.scalaide.worksheet.runtime.library.WorksheetSupport._; def main(args: Array[String])=$execute{;$skip(67); 
  println("Welcome to the Scala worksheet");$skip(52); 
  //Mutable vs Immutable
  val Hello:String="Hello";System.out.println("""Hello  : String = """ + $show(Hello ));$skip(32); 
  var HelloThere:String="There";System.out.println("""HelloThere  : String = """ + $show(HelloThere ));$skip(32); 
  HelloThere=Hello + HelloThere;$skip(22); 
  println(HelloThere);$skip(63); 
  
  // Initializing different datatypes
  val numberone:Int=1;System.out.println("""numberone  : Int = """ + $show(numberone ));$skip(25); 
  val truth:Boolean=true;System.out.println("""truth  : Boolean = """ + $show(truth ));$skip(23); 
  val letterA:Char='A';System.out.println("""letterA  : Char = """ + $show(letterA ));$skip(23); 
  val pi:Double=3.1417;System.out.println("""pi  : Double = """ + $show(pi ));$skip(36); 
  val piSinglePrecision:Float=3.14f;System.out.println("""piSinglePrecision  : Float = """ + $show(piSinglePrecision ));$skip(32); 
  val bigNumber:Long=1234567890;System.out.println("""bigNumber  : Long = """ + $show(bigNumber ));$skip(27); 
  val smallNumber:Byte=127;System.out.println("""smallNumber  : Byte = """ + $show(smallNumber ));$skip(182); 
  
  // Concatenating values of different types : implicit type conversion to string
  println("Here is a mess:"+ numberone+truth+letterA+pi+piSinglePrecision+bigNumber+smallNumber);$skip(72); 
  // Number formatting
  println(f"pi is about $piSinglePrecision%.1f");$skip(53); 
 println(f"Zero padding on the left:$numberone%05d");$skip(110); 
 //string substitution
 println(s"I can use the s prefix to use variables like $numberone $truth $bigNumber");$skip(99); 
println(s"The s prefix isn't limited to variables; I can include expression as well. like ${1+2}");$skip(91); 
//Regular Expressions
val theUltimateAnswer="To life, the universe, and everything is 42.";System.out.println("""theUltimateAnswer  : String = """ + $show(theUltimateAnswer ));$skip(32); 
val pattern=""".* ([\d]).*""".r;System.out.println("""pattern  : scala.util.matching.Regex = """ + $show(pattern ));$skip(44); 
val pattern(answerstring)=theUltimateAnswer;System.out.println("""answerstring  : String = """ + $show(answerstring ));$skip(30); 
val answer=answerstring.toInt;System.out.println("""answer  : Int = """ + $show(answer ));$skip(16); 
println(answer);$skip(52); 

// Dealing with Booleans
val isGreater:Boolean=1>2;System.out.println("""isGreater  : Boolean = """ + $show(isGreater ));$skip(25); 
val isLesser:Boolean=1<2;System.out.println("""isLesser  : Boolean = """ + $show(isLesser ));$skip(36); 
val impossible=isGreater & isLesser;System.out.println("""impossible  : Boolean = """ + $show(impossible ));$skip(37); 
val anotherway=isGreater && isLesser;System.out.println("""anotherway  : Boolean = """ + $show(anotherway ));$skip(21); 

val picard="Picard";System.out.println("""picard  : String = """ + $show(picard ));$skip(25); 
val bestcaptain="Picard";System.out.println("""bestcaptain  : String = """ + $show(bestcaptain ));$skip(39); 
val isBest:Boolean=picard==bestcaptain;System.out.println("""isBest  : Boolean = """ + $show(isBest ));$skip(97); 

// Flow control
// if else
if (1>3) println("Impossible") else println("The world makes sense");$skip(85); 
if (1>3)
{
println("Impossible")
}
else
{
println("The world makes perfect sense")
};$skip(60); 

// matching - switch case in other languages
val number =3;System.out.println("""number  : Int = """ + $show(number ));$skip(130); 
number match {
case 1 => println("One")
case 2 => println("Two")
case 3 => println("Three")
case _ => println("Something Else")
};$skip(70); 

// For loops
for (x<- 1 to 4)
{
val squared = x*x
println(squared)
};$skip(22); 
// while loop
var x=0;System.out.println("""x  : Int = """ + $show(x ));$skip(32); 
while(x>=10){
println(x)
x+=1
};$skip(18); 
//do while
 x = 0;$skip(42); 
  do { println(x); x+=1 } while (x <= 10);$skip(168); val res$0 = 
                                                  
   // Expressions
   // "Returns" the final value in a block automatically
 
 // Expression
    {val x = 10; x + 20};System.out.println("""res0: Int = """ + $show(res$0));$skip(41); 
    
    	 println({val x = 10; x + 20});$skip(219); 
    	 
 // Functions
 // Format is def <function name>(parameter name: type...) : return type = { expression }
  // Don't forget the = before the expression!
 
 // Square the number
 def squareInt(x:Int):Int ={
 x*x
 };System.out.println("""squareInt: (x: Int)Int""");$skip(57); 
 
 // Cube the number
 def cubeIt(x:Int):Int={
 x*x*x
 };System.out.println("""cubeIt: (x: Int)Int""");$skip(25); 
 
 println(squareInt(3));$skip(20); 
 println(cubeIt(3));$skip(105); 
 
 // using function as an argument to another function
 
 def transformInt(x:Int,f:Int=>Int)={
 f(x)
 };System.out.println("""transformInt: (x: Int, f: Int => Int)Int""");$skip(40); 
 
 val result = transformInt(10,cubeIt);System.out.println("""result  : Int = """ + $show(result ));$skip(17); 
 println(result);$skip(205); val res$1 = 
 
 
 // "Lambda functions", "anonymous functions", "function literals"
  // You can declare functions inline without even giving them a name
  // This happens a lot in Spark.
  
  transformInt(3,x=>x*x*x);System.out.println("""res1: Int = """ + $show(res$1));$skip(26); val res$2 = 
  transformInt(10,x=>x/2);System.out.println("""res2: Int = """ + $show(res$2));$skip(42); val res$3 = 
  
  transformInt(5,x=>{val y=x*2;y*y*4});System.out.println("""res3: Int = """ + $show(res$3));$skip(328); 
 
 
 // Collections
 // Data structures
  
  // Tuples (Also really common with Spark!!) - Index starts from 1
  // Immutable lists
  // Often thought of as database fields, or columns - elements of different types
  // Useful for passing around entire rows of data.
  
  val captainStuff=("Picard","Enterprise-D","NCC-1701-D");System.out.println("""captainStuff  : (String, String, String) = """ + $show(captainStuff ));$skip(27); 
  
  println(captainStuff);$skip(103); 
  
    // You refer to individual fields with their ONE-BASED index:
    
    println(captainStuff._1);$skip(29); 
    println(captainStuff._2);$skip(29); 
    println(captainStuff._3);$skip(100); 
    
    // You can create a key/value pair with ->
    val picardShip = "Picard" -> "Enterprise-D";System.out.println("""picardShip  : (String, String) = """ + $show(picardShip ));$skip(27); 
    println(picardShip._1);$skip(27); 
    println(picardShip._2);$skip(97); 
    
    // You can mix different types in a tuple
     val aBunchOfStuff = ("Kirk", 1964, true);System.out.println("""aBunchOfStuff  : (String, Int, Boolean) = """ + $show(aBunchOfStuff ));$skip(267); 
    
   // Lists - Index starts from 0 - elements of same type
 // Like a tuple, but it's an actual Collection object that has more functionality.
 // It's a singly-linked list under the hood.
 
 val shipList=List("Enterprise","Defiant","Voyager","Deep Space Nine");System.out.println("""shipList  : List[String] = """ + $show(shipList ));$skip(22); 
 println(shipList(0));$skip(95); 
 
 // head and tail give you the first item, and the remaining ones.
 
 println(shipList.head);$skip(24); 
 println(shipList.tail);$skip(44); 
 
 for (ship <- shipList)
 {
 println(ship)
 };$skip(187); 
 
 // Let's apply a function literal to a list! map() can be used to apply any function to every item in a collection.
 
 val shipReverse= shipList.map((ship:String)=> {ship.reverse});System.out.println("""shipReverse  : List[String] = """ + $show(shipReverse ));$skip(72); 
 
 // reduce function to compute the sum
 val testList =List(1,2,3,4,5);System.out.println("""testList  : List[Int] = """ + $show(testList ));$skip(51); 
 val sum = testList.reduce((x:Int,y:Int) => {x+y});System.out.println("""sum  : Int = """ + $show(sum ));$skip(91); 
 
 // filter the list to remove value 2
 val filterList = testList.filter((x:Int)=>{x!=2});System.out.println("""filterList  : List[Int] = """ + $show(filterList ));$skip(43); 
 
 val filterList2 = testList.filter(_!=2);System.out.println("""filterList2  : List[Int] = """ + $show(filterList2 ));$skip(233); 
 
 
 // Note that Spark has its own map, reduce, and filter functions that can distribute these operations. But they work the same way!
// Also, you understand MapReduce now :)

// Concatenating lists
val moreNumbers=List(8,9,0,1,7);System.out.println("""moreNumbers  : List[Int] = """ + $show(moreNumbers ));$skip(38); 
val newList = testList ++ moreNumbers;System.out.println("""newList  : List[Int] = """ + $show(newList ));$skip(56); 

// more List Operations
val reversed = newList.reverse;System.out.println("""reversed  : List[Int] = """ + $show(reversed ));$skip(29); 
val sorted = reversed.sorted;System.out.println("""sorted  : List[Int] = """ + $show(sorted ));$skip(31); 
val distinct = sorted.distinct;System.out.println("""distinct  : List[Int] = """ + $show(distinct ));$skip(23); 
val max = distinct.max;System.out.println("""max  : Int = """ + $show(max ));$skip(23); 
val min = distinct.min;System.out.println("""min  : Int = """ + $show(min ));$skip(26); 
val sumall = distinct.sum;System.out.println("""sumall  : Int = """ + $show(sumall ));$skip(34); 
val is5there=distinct.contains(5);System.out.println("""is5there  : Boolean = """ + $show(is5there ));$skip(224); 


// Maps
// Useful for key/value lookups on distinct keys
// Like dictionaries in other languages

val shipMap = Map("Kirk" -> "Enterprise", "Picard" -> "Enterprise-D", "Sisko" -> "Deep Space Nine", "Janeway" -> "Voyager");System.out.println("""shipMap  : scala.collection.immutable.Map[String,String] = """ + $show(shipMap ));$skip(26); 
println(shipMap("Sisko"));$skip(67); 

// Dealing with missing keys
println(shipMap.contains("Archer"));$skip(67); 

val archersShip = util.Try(shipMap("Archer")) getOrElse "Unknown";System.out.println("""archersShip  : String = """ + $show(archersShip ));$skip(65); 
val PicardShip = util.Try(shipMap("Picard")) getOrElse "Unknown";System.out.println("""PicardShip  : String = """ + $show(PicardShip ));$skip(37); 

// Other Operations
val x1 = 2 to 9;System.out.println("""x1  : scala.collection.immutable.Range.Inclusive = """ + $show(x1 ));$skip(22); val res$4 = 
1.0f.getClass.getName;System.out.println("""res4: String = """ + $show(res$4));$skip(23); 
val s = "Hello, world";System.out.println("""s  : String = """ + $show(s ));$skip(9); val res$5 = 
s.length;System.out.println("""res5: Int = """ + $show(res$5));$skip(19); 
s.foreach(println);$skip(29); val res$6 = 
s.drop(2).take(2).capitalize;System.out.println("""res6: String = """ + $show(res$6));$skip(43); 
val foo = """This is
a multiline
String""";System.out.println("""foo  : String = """ + $show(foo ));$skip(65); 

val speech = """Four score and
|seven years ago""".stripMargin;System.out.println("""speech  : String = """ + $show(speech ));$skip(17); 

println(speech);$skip(69); 
val speech1 = """Four score and
#seven years ago""".stripMargin('#');System.out.println("""speech1  : String = """ + $show(speech1 ));$skip(99); 
val speech2 = """Four score and
|seven years ago
|our fathers""".stripMargin.replaceAll("\n", " ");System.out.println("""speech2  : String = """ + $show(speech2 ));$skip(26); val res$7 = 

"hello world".split(" ");System.out.println("""res7: Array[String] = """ + $show(res$7));$skip(55); 

val commadelimited = "eggs, milk, butter, Coco Puffs";System.out.println("""commadelimited  : String = """ + $show(commadelimited ));$skip(62); 
 
val arraycommadelim = commadelimited.split(",").map(_.trim);System.out.println("""arraycommadelim  : Array[String] = """ + $show(arraycommadelim ));$skip(41); val res$8 = 

"hello world, this is Al".split("\\s+");System.out.println("""res8: Array[String] = """ + $show(res$8));$skip(29); 

val numPattern = "[0-9]+".r;System.out.println("""numPattern  : scala.util.matching.Regex = """ + $show(numPattern ));$skip(42); 
val address = "123 Main Street Suite 101";System.out.println("""address  : String = """ + $show(address ));$skip(49); 
val firstMatch = numPattern.findFirstIn(address);System.out.println("""firstMatch  : Option[String] = """ + $show(firstMatch ));$skip(47); 
val allMatches = numPattern.findAllIn(address);System.out.println("""allMatches  : scala.util.matching.Regex.MatchIterator = """ + $show(allMatches ));$skip(28); 
allMatches.foreach(println);$skip(55); 
val matchArray = numPattern.findAllIn(address).toArray;System.out.println("""matchArray  : Array[String] = """ + $show(matchArray ))}

}
