class MyScalaClass 

object ScalaTestApp {
  def main(args:Array[String])
  {
    
  }
}