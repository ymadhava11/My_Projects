

object CaseClassDemo {
  // Pattern Matching and case classes

abstract class DelimitedLine

case class TabDelimited() extends DelimitedLine
case class CommaDelimited() extends DelimitedLine
case class SpaceDelimited() extends DelimitedLine

def delimiter(d:DelimitedLine): String = d match
{
 case TabDelimited() => "\t"
 case CommaDelimited() => ","
 case SpaceDelimited() => " "
 }

val a:DelimitedLine = new CommaDelimited()
val b:DelimitedLine = SpaceDelimited()

// object creation of  a & b are the same, can follow one of these

println(a.toString)
println("a" + delimiter(a) + "b")
println(a==b)
}